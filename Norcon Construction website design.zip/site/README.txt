Norcon Construction — buildnorthern.ca
Upload the CONTENTS of this folder to your web root (not the folder itself).

  index.html      The site. Plain static HTML — search engines and social
                  scrapers read the content and meta tags without running JS.
  robots.txt      Allows indexing; points to the sitemap.
  sitemap.xml     Single-page sitemap.
  assets/         Logos, hero photo, favicon, social share image.
                  Keep this folder name — meta tags reference
                  buildnorthern.ca/assets/ by absolute URL.

After uploading:
  1. Re-scan at https://www.opengraph.xyz/ — all tags should now be found.
  2. Verify the domain in Google Search Console and submit
     https://buildnorthern.ca/sitemap.xml
  3. Create a Google Business Profile for each office (Sudbury, Timmins).
     This is the biggest driver of local search results.

Note: the .dc.html file in the main project is the editable design source.
This folder is the built output for hosting.
